class FitnessCoach {
    constructor() {
        this.openAIService = new OpenAIService('YOUR_OPENAI_API_KEY'); // Replace with your API key
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        const userForm = document.getElementById('userForm');
        const backButton = document.getElementById('backBtn');

        userForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.generateWorkoutPlan();
        });

        backButton.addEventListener('click', () => {
            document.getElementById('planSection').style.display = 'none';
            document.querySelector('.input-section').style.display = 'block';
        });
    }

    async generateWorkoutPlan() {
        const userData = {
            age: parseInt(document.getElementById('age').value),
            weight: parseInt(document.getElementById('weight').value),
            height: parseInt(document.getElementById('height').value),
            fitnessLevel: document.getElementById('fitnessLevel').value,
            goal: document.getElementById('goal').value,
            schedule: {
                availableDays: ['Monday', 'Wednesday', 'Friday'],
                preferredTime: 'morning',
                workoutDuration: 60
            }
        };

        // Show loading spinner
        document.querySelector('.input-section').style.display = 'none';
        document.getElementById('planSection').style.display = 'block';
        document.getElementById('loadingSpinner').style.display = 'block';
        document.getElementById('workoutPlan').style.display = 'none';

        try {
            // Get AI recommendations
            const [workoutPlan, dietPlan, progressAnalysis] = await Promise.all([
                this.openAIService.getWorkoutRecommendation(userData, userData.goal),
                this.openAIService.getDietRecommendation(userData, userData.goal),
                this.openAIService.getProgressAnalysis(userData, {
                    currentWeight: userData.weight,
                    startingWeight: userData.weight,
                    workoutConsistency: 0,
                    goal: userData.goal
                })
            ]);

            // Update workout plan display
            document.getElementById('schedule').innerHTML = `
                <p>${workoutPlan.schedule}</p>
                <ul>
                    ${workoutPlan.exercises.map(exercise => `<li>${exercise}</li>`).join('')}
                </ul>
                <p><strong>Intensity:</strong> ${workoutPlan.intensity}</p>
                <p><strong>Rest Periods:</strong> ${workoutPlan.restPeriods}</p>
            `;

            document.getElementById('exercises').innerHTML = `
                <ul>
                    ${workoutPlan.metrics.map(metric => `<li>${metric}</li>`).join('')}
                </ul>
            `;

            document.getElementById('diet').innerHTML = `
                <p><strong>Daily Calories:</strong> ${dietPlan.calories}</p>
                <p><strong>Macronutrients:</strong></p>
                <ul>
                    <li>Protein: ${dietPlan.macros.protein}g</li>
                    <li>Carbs: ${dietPlan.macros.carbs}g</li>
                    <li>Fats: ${dietPlan.macros.fats}g</li>
                </ul>
                <p><strong>Meal Timing:</strong></p>
                <ul>
                    ${dietPlan.mealTiming.map(meal => `<li>${meal}</li>`).join('')}
                </ul>
                <p><strong>Food Suggestions:</strong></p>
                <ul>
                    ${dietPlan.foodSuggestions.map(food => `<li>${food}</li>`).join('')}
                </ul>
                <p><strong>Hydration:</strong> ${dietPlan.hydration}</p>
            `;

            document.getElementById('progress').innerHTML = `
                <p>${progressAnalysis.analysis}</p>
                <h4>Recommendations:</h4>
                <ul>
                    ${progressAnalysis.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                </ul>
                <h4>Next Milestones:</h4>
                <ul>
                    ${progressAnalysis.milestones.map(milestone => `<li>${milestone}</li>`).join('')}
                </ul>
                <h4>Suggested Adjustments:</h4>
                <ul>
                    ${progressAnalysis.adjustments.map(adj => `<li>${adj}</li>`).join('')}
                </ul>
            `;

            // Hide loading spinner and show workout plan
            document.getElementById('loadingSpinner').style.display = 'none';
            document.getElementById('workoutPlan').style.display = 'block';
        } catch (error) {
            console.error('Error generating workout plan:', error);
            alert('Error generating workout plan. Please try again later.');
            document.getElementById('loadingSpinner').style.display = 'none';
            document.querySelector('.input-section').style.display = 'block';
            document.getElementById('planSection').style.display = 'none';
        }
    }
}

// Initialize the fitness coach when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.fitnessCoach = new FitnessCoach();
}); 