import random
from typing import Dict, List
from colorama import init, Back, Fore, Style

# Initialize colorama
init()

class FitnessCoach:
    def __init__(self):
        self.workout_templates = {
            "weight_loss": {
                "cardio": ["Running", "Cycling", "Jump Rope", "Swimming", "HIIT"],
                "strength": ["Bodyweight Squats", "Push-ups", "Lunges", "Plank", "Mountain Climbers"],
                "duration": "45-60 minutes",
                "frequency": "4-5 times per week",
                "diet": {
                    "calories": "Caloric deficit of 500-700 calories per day",
                    "protein": "1.6-2.0g per kg of body weight",
                    "carbs": "40-50% of total calories",
                    "fats": "20-30% of total calories",
                    "meals": [
                        "Breakfast: Protein-rich meal with complex carbs",
                        "Lunch: Lean protein with vegetables",
                        "Dinner: Light protein with vegetables",
                        "Snacks: Protein shakes, fruits, nuts"
                    ]
                }
            },
            "muscle_gain": {
                "strength": ["Bench Press", "Squats", "Deadlifts", "Pull-ups", "Shoulder Press"],
                "accessory": ["Bicep Curls", "Tricep Extensions", "Lateral Raises", "Leg Press"],
                "duration": "60-90 minutes",
                "frequency": "4-5 times per week",
                "diet": {
                    "calories": "Caloric surplus of 300-500 calories per day",
                    "protein": "2.0-2.2g per kg of body weight",
                    "carbs": "50-60% of total calories",
                    "fats": "20-30% of total calories",
                    "meals": [
                        "Breakfast: High-protein meal with complex carbs",
                        "Lunch: Protein-rich meal with rice/potatoes",
                        "Dinner: Protein with complex carbs",
                        "Snacks: Protein shakes, Greek yogurt, nuts"
                    ]
                }
            },
            "endurance": {
                "cardio": ["Long Distance Running", "Cycling", "Rowing", "Stair Climbing"],
                "strength": ["Circuit Training", "Bodyweight Exercises", "Light Weight Training"],
                "duration": "60-75 minutes",
                "frequency": "5-6 times per week",
                "diet": {
                    "calories": "Maintenance calories",
                    "protein": "1.4-1.6g per kg of body weight",
                    "carbs": "55-65% of total calories",
                    "fats": "20-25% of total calories",
                    "meals": [
                        "Breakfast: Complex carbs with protein",
                        "Lunch: Balanced meal with carbs and protein",
                        "Dinner: Protein with vegetables",
                        "Snacks: Energy bars, fruits, nuts"
                    ]
                }
            },
            "flexibility": {
                "stretching": ["Dynamic Stretching", "Static Stretching", "Yoga Poses", "Mobility Exercises"],
                "strength": ["Bodyweight Exercises", "Light Resistance Training"],
                "duration": "30-45 minutes",
                "frequency": "5-6 times per week",
                "diet": {
                    "calories": "Maintenance calories",
                    "protein": "1.2-1.4g per kg of body weight",
                    "carbs": "45-55% of total calories",
                    "fats": "25-35% of total calories",
                    "meals": [
                        "Breakfast: Balanced meal with protein",
                        "Lunch: Protein with vegetables",
                        "Dinner: Light protein with vegetables",
                        "Snacks: Fruits, nuts, yogurt"
                    ]
                }
            }
        }
        
        self.muscle_maintenance_tips = [
            "Maintain consistent protein intake",
            "Stay hydrated throughout the day",
            "Get adequate sleep (7-9 hours)",
            "Include rest days in your routine",
            "Vary your exercises to prevent plateaus",
            "Focus on proper form over weight",
            "Consider periodization in your training",
            "Track your progress regularly"
        ]

    def get_workout_plan(self, goal: str) -> Dict:
        goal = goal.lower().replace(" ", "_")
        if goal not in self.workout_templates:
            return {"error": "Invalid goal. Please choose from: weight loss, muscle gain, endurance, or flexibility."}
        
        template = self.workout_templates[goal]
        workout_plan = {
            "goal": goal.replace("_", " ").title(),
            "duration": template["duration"],
            "frequency": template["frequency"],
            "exercises": [],
            "diet": template["diet"],
            "muscle_maintenance": random.sample(self.muscle_maintenance_tips, 4)
        }

        # Add exercises from each category
        for category in template:
            if category not in ["duration", "frequency", "diet"]:
                exercises = template[category]
                selected_exercises = random.sample(exercises, min(3, len(exercises)))
                workout_plan["exercises"].extend(selected_exercises)

        return workout_plan

def main():
    coach = FitnessCoach()
    print(f"{Back.RED}{Fore.WHITE}Welcome to AI Fitness Coach!{Style.RESET_ALL}")
    print(f"{Back.RED}{Fore.WHITE}\nAvailable goals:{Style.RESET_ALL}")
    print(f"{Back.RED}{Fore.WHITE}1. Weight Loss{Style.RESET_ALL}")
    print(f"{Back.RED}{Fore.WHITE}2. Muscle Gain{Style.RESET_ALL}")
    print(f"{Back.RED}{Fore.WHITE}3. Endurance{Style.RESET_ALL}")
    print(f"{Back.RED}{Fore.WHITE}4. Flexibility{Style.RESET_ALL}")
    
    while True:
        goal = input(f"{Back.RED}{Fore.WHITE}\nEnter your fitness goal (or 'quit' to exit): {Style.RESET_ALL}").strip()
        
        if goal.lower() == 'quit':
            print(f"{Back.RED}{Fore.WHITE}Thank you for using AI Fitness Coach. Stay fit!{Style.RESET_ALL}")
            break
            
        workout_plan = coach.get_workout_plan(goal)
        
        if "error" in workout_plan:
            print(f"{Back.RED}{Fore.WHITE}{workout_plan['error']}{Style.RESET_ALL}")
            continue
            
        print(f"{Back.RED}{Fore.WHITE}\nYour Personalized Workout Plan:{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Goal: {workout_plan['goal']}{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Recommended Duration: {workout_plan['duration']}{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Frequency: {workout_plan['frequency']}{Style.RESET_ALL}")
        
        print(f"{Back.RED}{Fore.WHITE}\nExercises:{Style.RESET_ALL}")
        for i, exercise in enumerate(workout_plan['exercises'], 1):
            print(f"{Back.RED}{Fore.WHITE}{i}. {exercise}{Style.RESET_ALL}")
        
        print(f"{Back.RED}{Fore.WHITE}\nDiet Plan:{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Calories: {workout_plan['diet']['calories']}{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Protein: {workout_plan['diet']['protein']}{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Carbohydrates: {workout_plan['diet']['carbs']}{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}Fats: {workout_plan['diet']['fats']}{Style.RESET_ALL}")
        
        print(f"{Back.RED}{Fore.WHITE}\nRecommended Meals:{Style.RESET_ALL}")
        for meal in workout_plan['diet']['meals']:
            print(f"{Back.RED}{Fore.WHITE}- {meal}{Style.RESET_ALL}")
        
        print(f"{Back.RED}{Fore.WHITE}\nMuscle Maintenance Tips:{Style.RESET_ALL}")
        for tip in workout_plan['muscle_maintenance']:
            print(f"{Back.RED}{Fore.WHITE}- {tip}{Style.RESET_ALL}")
        
        print(f"{Back.RED}{Fore.WHITE}\nRemember to:{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}- Warm up before starting your workout{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}- Stay hydrated throughout your session{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}- Listen to your body and rest when needed{Style.RESET_ALL}")
        print(f"{Back.RED}{Fore.WHITE}- Maintain proper form during exercises{Style.RESET_ALL}")

if __name__ == "__main__":
    main() 