class OpenAIService {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.baseUrl = 'https://api.openai.com/v1/chat/completions';
    }

    async getWorkoutRecommendation(userData, goal) {
        const prompt = this.createWorkoutPrompt(userData, goal);
        try {
            const response = await this.makeApiCall(prompt);
            return this.parseWorkoutResponse(response);
        } catch (error) {
            console.error('Error getting workout recommendation:', error);
            return this.getFallbackWorkoutPlan(goal);
        }
    }

    async getDietRecommendation(userData, goal) {
        const prompt = this.createDietPrompt(userData, goal);
        try {
            const response = await this.makeApiCall(prompt);
            return this.parseDietResponse(response);
        } catch (error) {
            console.error('Error getting diet recommendation:', error);
            return this.getFallbackDietPlan(goal);
        }
    }

    async getProgressAnalysis(userData, progress) {
        const prompt = this.createProgressPrompt(userData, progress);
        try {
            const response = await this.makeApiCall(prompt);
            return this.parseProgressResponse(response);
        } catch (error) {
            console.error('Error getting progress analysis:', error);
            return this.getFallbackProgressAnalysis();
        }
    }

    async makeApiCall(prompt) {
        const response = await fetch(this.baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.apiKey}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [
                    {
                        role: "system",
                        content: "You are an expert fitness coach and nutritionist."
                    },
                    {
                        role: "user",
                        content: prompt
                    }
                ],
                temperature: 0.7,
                max_tokens: 500
            })
        });

        if (!response.ok) {
            throw new Error('API call failed');
        }

        return await response.json();
    }

    createWorkoutPrompt(userData, goal) {
        return `Create a personalized workout plan for a ${userData.fitnessLevel} level user with the following details:
        - Age: ${userData.age}
        - Weight: ${userData.weight}kg
        - Height: ${userData.height}cm
        - Goal: ${goal}
        - Available days: ${userData.schedule.availableDays.join(', ')}
        - Preferred workout duration: ${userData.schedule.workoutDuration} minutes
        
        Please provide:
        1. Weekly workout schedule
        2. Exercise recommendations
        3. Intensity levels
        4. Rest periods
        5. Progress tracking metrics`;
    }

    createDietPrompt(userData, goal) {
        return `Create a personalized diet plan for a ${userData.fitnessLevel} level user with the following details:
        - Age: ${userData.age}
        - Weight: ${userData.weight}kg
        - Height: ${userData.height}cm
        - Goal: ${goal}
        
        Please provide:
        1. Daily calorie target
        2. Macronutrient breakdown
        3. Meal timing recommendations
        4. Food suggestions
        5. Hydration guidelines`;
    }

    createProgressPrompt(userData, progress) {
        return `Analyze the following fitness progress data:
        - Current weight: ${progress.currentWeight}kg
        - Starting weight: ${progress.startingWeight}kg
        - Workout consistency: ${progress.workoutConsistency}%
        - Goal: ${progress.goal}
        
        Please provide:
        1. Progress analysis
        2. Recommendations for improvement
        3. Next milestone suggestions
        4. Potential adjustments needed`;
    }

    parseWorkoutResponse(response) {
        try {
            const content = response.choices[0].message.content;
            return {
                schedule: this.extractSchedule(content),
                exercises: this.extractExercises(content),
                intensity: this.extractIntensity(content),
                restPeriods: this.extractRestPeriods(content),
                metrics: this.extractMetrics(content)
            };
        } catch (error) {
            console.error('Error parsing workout response:', error);
            return this.getFallbackWorkoutPlan();
        }
    }

    parseDietResponse(response) {
        try {
            const content = response.choices[0].message.content;
            return {
                calories: this.extractCalories(content),
                macros: this.extractMacros(content),
                mealTiming: this.extractMealTiming(content),
                foodSuggestions: this.extractFoodSuggestions(content),
                hydration: this.extractHydration(content)
            };
        } catch (error) {
            console.error('Error parsing diet response:', error);
            return this.getFallbackDietPlan();
        }
    }

    parseProgressResponse(response) {
        try {
            const content = response.choices[0].message.content;
            return {
                analysis: this.extractAnalysis(content),
                recommendations: this.extractRecommendations(content),
                milestones: this.extractMilestones(content),
                adjustments: this.extractAdjustments(content)
            };
        } catch (error) {
            console.error('Error parsing progress response:', error);
            return this.getFallbackProgressAnalysis();
        }
    }

    // Helper methods for parsing responses
    extractSchedule(content) {
        // Implementation for extracting schedule
        return "Weekly workout schedule";
    }

    extractExercises(content) {
        // Implementation for extracting exercises
        return ["Exercise 1", "Exercise 2", "Exercise 3"];
    }

    extractIntensity(content) {
        // Implementation for extracting intensity
        return "Moderate";
    }

    extractRestPeriods(content) {
        // Implementation for extracting rest periods
        return "60 seconds between sets";
    }

    extractMetrics(content) {
        // Implementation for extracting metrics
        return ["Weight", "Reps", "Sets"];
    }

    extractCalories(content) {
        // Implementation for extracting calories
        return 2000;
    }

    extractMacros(content) {
        // Implementation for extracting macros
        return {
            protein: 150,
            carbs: 200,
            fats: 70
        };
    }

    extractMealTiming(content) {
        // Implementation for extracting meal timing
        return ["Breakfast", "Lunch", "Dinner"];
    }

    extractFoodSuggestions(content) {
        // Implementation for extracting food suggestions
        return ["Food 1", "Food 2", "Food 3"];
    }

    extractHydration(content) {
        // Implementation for extracting hydration
        return "2-3 liters per day";
    }

    extractAnalysis(content) {
        // Implementation for extracting analysis
        return "Progress analysis";
    }

    extractRecommendations(content) {
        // Implementation for extracting recommendations
        return ["Recommendation 1", "Recommendation 2"];
    }

    extractMilestones(content) {
        // Implementation for extracting milestones
        return ["Milestone 1", "Milestone 2"];
    }

    extractAdjustments(content) {
        // Implementation for extracting adjustments
        return ["Adjustment 1", "Adjustment 2"];
    }

    // Fallback methods
    getFallbackWorkoutPlan(goal) {
        return {
            schedule: "3-4 times per week",
            exercises: ["Basic exercises"],
            intensity: "Moderate",
            restPeriods: "60 seconds",
            metrics: ["Basic metrics"]
        };
    }

    getFallbackDietPlan(goal) {
        return {
            calories: 2000,
            macros: {
                protein: 150,
                carbs: 200,
                fats: 70
            },
            mealTiming: ["Breakfast", "Lunch", "Dinner"],
            foodSuggestions: ["Basic foods"],
            hydration: "2-3 liters per day"
        };
    }

    getFallbackProgressAnalysis() {
        return {
            analysis: "Basic analysis",
            recommendations: ["Basic recommendations"],
            milestones: ["Basic milestones"],
            adjustments: ["Basic adjustments"]
        };
    }
} 